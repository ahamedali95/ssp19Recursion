//
//  testingViewController.swift
//  Dicey
//
//  Created by Ahamed Abbas on 11/24/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import UIKit

class gameListViewController: UIViewController
{
    @IBOutlet weak var image: UIImageView!
    
    var amount = [String]();
    override func viewDidLoad()
    {
        super.viewDidLoad();
        print("testingviewcontroller:  \(amount)");
        image.loadGif(name: "bulbIcon");
        image.layer.borderWidth = 1;
        image.layer.masksToBounds = false;
        image.layer.cornerRadius = image.frame.height/2;
        image.clipsToBounds = true;
    }

    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func game1Button(_ sender: UIButton)
    {
        self.performSegue(withIdentifier: "game1View", sender: self);
    }
    
    @IBAction func game2Button(_ sender: UIButton)
    {
        self.performSegue(withIdentifier: "game2View", sender: self);
    }
    @IBAction func game3Button(_ sender: UIButton)
    {
        self.performSegue(withIdentifier: "game3View", sender: self);
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if (segue.identifier == "game1View")
        {
            let game1View: Game1ViewController = segue.destination as! Game1ViewController;
            game1View.amount = amount;
        }
        else if (segue.identifier == "game2View")
        {
            let game2View: Game2ViewController = segue.destination as! Game2ViewController;
            game2View.amount = amount;
        }
        else if (segue.identifier == "game3View")
        {
            let game3View: Game3ViewController = segue.destination as! Game3ViewController;
            game3View.amount = amount;
        }
    }
}
