//
//  Game2ViewController.swift
//  Dicey
//
//  Created by Ahamed Abbas on 11/21/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import UIKit

class Game2ViewController: UIViewController
{
    @IBOutlet weak var amount1Label: UILabel!
    @IBOutlet weak var amount2Label: UILabel!
    @IBOutlet weak var amount3Label: UILabel!
    @IBOutlet weak var amount4Label: UILabel!
    @IBOutlet weak var amount5Label: UILabel!
    @IBOutlet weak var amount6Label: UILabel!
    
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad()
    {
        imageView.loadGif(name: "game2Logo");
    }
    var amount = [String]();
    var finalAmount = 0;
    let amountHolder1 = [10,20,30,40,50,100];
    var allButtonTouchCheck = [String]();
    var amountArr = [Int]();
    
    func generateAmount1() -> Int
    {
        let num = Int(arc4random_uniform(UInt32(amountHolder1.count - 1)) + 0);
        let amount = amountHolder1[num];
        return amount;
    }
    
    @IBAction func amount1(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount1");
        let amount = generateAmount1();
        amountArr.append(amount);
        amount1Label.text = "$" + "\(amount)";
        sender.isHidden = true;
    }
    
    @IBAction func amount2(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount2");
        let amount = generateAmount1();
        amountArr.append(amount);
        amount2Label.text = "$" + "\(amount)";
        sender.isHidden = true;
    }
    
    @IBAction func amount3(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount3");
        let amount = generateAmount1();
        amountArr.append(amount);
        amount3Label.text = "$" + "\(amount)";
        sender.isHidden = true;
    }
    
    @IBAction func amount4(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount4");
        let amount = generateAmount1();
        amountArr.append(amount);
        amount4Label.text = "$" + "\(amount)";
        sender.isHidden = true;
    }
    
    @IBAction func amount5(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount5");
        let amount = generateAmount1();
        amountArr.append(amount);
        amount5Label.text = "$" + "\(amount)";
        sender.isHidden = true;
    }
    
    @IBAction func amount6(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount6");
        let amount = generateAmount1();
        amountArr.append(amount);
        amount6Label.text = "$" + "\(amount)";
        sender.isHidden = true;
    }
    
    @IBAction func finish(_ sender: UIButton)
    {
        if (allButtonTouchCheck.count < 6)
        {
            let alertController = UIAlertController(title: "Alert", message:
                "Please scratch off all slots", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
            
            self.present(alertController, animated: true, completion: nil)
        }
        if (allButtonTouchCheck.count == 6)
        {
            let amountWon = calculateAmount();
            finalAmount = amountWon;
            allButtonTouchCheck.removeAll();
            amountArr.removeAll();
            
            //segue to EndViewController
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2))
            {
                self.performSegue(withIdentifier: "endViewForGame2", sender: self)
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let endView: EndViewController = segue.destination as! EndViewController;
        endView.amount = "\(finalAmount)";
        amount.append("Lady Luck 3 - $\(finalAmount)");
        endView.amountArr = amount;
        endView.comingFrom = "LadyLuck3";
    }
    
    func calculateAmount() -> Int
    {
        var count = 0;
        var amount = [Int]();
        
        let startIndex = 0;
        let endIndex = amountArr.count;
        let increment = 1;
        
        let sequence = stride(from: startIndex, to: endIndex, by: increment)
        
        //nestedLooop to see whether a element exists thrice in an array
        for i in sequence
        {
            let amount1 = amountArr[i];
            
            for j in sequence
            {
                let amount2 = amountArr[j];
                
                if (amount1 == amount2)
                {
                    count += 1;
                }
            }
            
            //if the count >= 3 then reset count and make sure the element does not exist in the array. If it does not, then insert.
            if (count >= 3) {
                count = 0;
                
                if (amount.contains(amount1) == false)
                {
                    amount.append(amount1);
                }
            }
            else
            {
                count = 0;
            }
        }
        
        //we have a function call and this function has a loop to get the total amount won. Sometimes, the user might win 2 likely amounts.
        let amountWon = getArraySum(arr: amount);
        return amountWon;
    }
    
    func getArraySum(arr: Array<Int>) -> Int
    {
        let startIndex = 0;
        let endIndex = arr.count;
        let increment = 1;
        var sum = 0;
        
        let sequence = stride(from: startIndex, to: endIndex, by: increment)
        
        for i in sequence
        {
            sum += arr[i];
        }
        
        return sum;
    }
    
}
