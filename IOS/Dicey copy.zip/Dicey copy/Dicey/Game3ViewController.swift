//
//  Game3ViewController.swift
//  Dicey
//
//  Created by Ahamed Abbas on 11/23/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import UIKit

class Game3ViewController: UIViewController
{
    @IBOutlet weak var symbolLabel1: UILabel!
    @IBOutlet weak var symbolLabel2: UILabel!
    @IBOutlet weak var symbolLabel3: UILabel!
    @IBOutlet weak var symbolLabel4: UILabel!
    @IBOutlet weak var symbolLabel5: UILabel!
    @IBOutlet weak var symbolLabel6: UILabel!
    @IBOutlet weak var symbolLabel7: UILabel!
    @IBOutlet weak var symbolLabel8: UILabel!
    @IBOutlet weak var symbolLabel9: UILabel!
    @IBOutlet weak var symbolLabel10: UILabel!
    
    @IBOutlet weak var amountLabel1: UILabel!
    @IBOutlet weak var amountLabel2: UILabel!
    @IBOutlet weak var amountLabel3: UILabel!
    @IBOutlet weak var amountLabel4: UILabel!
    @IBOutlet weak var amountLabel5: UILabel!
    @IBOutlet weak var amountLabel6: UILabel!
    @IBOutlet weak var amountLabel7: UILabel!
    @IBOutlet weak var amountLabel8: UILabel!
    @IBOutlet weak var amountLabel9: UILabel!
    @IBOutlet weak var amountLabel10: UILabel!
    
    var finalAmount = 0;
    let symbols = ["💵","🍒","⭐","💰","3X","🐷","♥️","👑","🌈","💎","🍖"];
    let amountHolder = [25,5,10,1,100,1000,3,5,20];
    
    var allButtonTouchCheck = [String]();
    
    struct symbolAndAmount
    {
        var symbol: String;
        var amount: Int;
        var label: UILabel;
    }
    
    var arr = [symbolAndAmount]();
    
    func generateSymbol() -> String
    {
        let num = Int(arc4random_uniform(UInt32(symbols.count - 1)) + 0);
        let symbol = symbols[num];
        return symbol;
    }
    
    func generateAmount() -> Int
    {
        let num = Int(arc4random_uniform(UInt32(amountHolder.count - 1)) + 0);
        let amount = amountHolder[num];
        return amount;
    }
    
    @IBAction func scratch1(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount1");
        let symbol = generateSymbol();
        symbolLabel1.text = symbol;
        let amount = generateAmount();
        amountLabel1.text = "$" + "\(amount)";
        arr.append(symbolAndAmount(symbol: symbol, amount: amount, label: amountLabel1));
        sender.isHidden = true;
    }
    
    @IBAction func scratch2(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount2");
        let symbol = generateSymbol();
        symbolLabel2.text = symbol;
        let amount = generateAmount();
        amountLabel2.text = "$" + "\(amount)";
        arr.append(symbolAndAmount(symbol: symbol, amount: amount, label: amountLabel2));
        sender.isHidden = true;
    }
    
    @IBAction func scratch3(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount3");
        let symbol = generateSymbol();
        symbolLabel3.text = symbol;
        let amount = generateAmount();
        amountLabel3.text = "$" + "\(amount)";
        arr.append(symbolAndAmount(symbol: symbol, amount: amount, label: amountLabel3));
        sender.isHidden = true;
    }
    
    @IBAction func scratch4(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount4");
        let symbol = generateSymbol();
        symbolLabel4.text = symbol;
        let amount = generateAmount();
        amountLabel4.text = "$" + "\(amount)";
        arr.append(symbolAndAmount(symbol: symbol, amount: amount, label: amountLabel4));
        sender.isHidden = true;
    }
    @IBAction func scratch5(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount5");
        let symbol = generateSymbol();
        symbolLabel5.text = symbol;
        let amount = generateAmount();
        amountLabel5.text = "$" + "\(amount)";
        arr.append(symbolAndAmount(symbol: symbol, amount: amount, label: amountLabel5));
        sender.isHidden = true;
    }
    
    @IBAction func scratch6(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount6");
        let symbol = generateSymbol();
        symbolLabel6.text = symbol;
        let amount = generateAmount();
        amountLabel6.text = "$" + "\(amount)";
        arr.append(symbolAndAmount(symbol: symbol, amount: amount, label: amountLabel6));
        sender.isHidden = true;
    }
    @IBAction func scratch7(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount7");
        let symbol = generateSymbol();
        symbolLabel7.text = symbol;
        let amount = generateAmount();
        amountLabel7.text = "$" + "\(amount)";
        arr.append(symbolAndAmount(symbol: symbol, amount: amount, label: amountLabel7));
        sender.isHidden = true;
    }
    
    @IBAction func scratch8(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount8");
        let symbol = generateSymbol();
        symbolLabel8.text = symbol;
        let amount = generateAmount();
        amountLabel8.text = "$" + "\(amount)";
        arr.append(symbolAndAmount(symbol: symbol, amount: amount, label: amountLabel8));
        sender.isHidden = true;
    }
    @IBAction func scratch9(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount9");
        let symbol = generateSymbol();
        symbolLabel9.text = symbol;
        let amount = generateAmount();
        amountLabel9.text = "$" + "\(amount)";
        arr.append(symbolAndAmount(symbol: symbol, amount: amount, label: amountLabel9));
        sender.isHidden = true;
    }
    
    @IBAction func scratch10(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount10");
        let symbol = generateSymbol();
        symbolLabel10.text = symbol;
        let amount = generateAmount();
        amountLabel10.text = "$" + "\(amount)";
        arr.append(symbolAndAmount(symbol: symbol, amount: amount, label: amountLabel10));
        sender.isHidden = true;
    }
    
    @IBAction func finish(_ sender: UIButton)
    {
        if (allButtonTouchCheck.count < 10)
        {
            let alertController = UIAlertController(title: "Alert", message:
                "Please scratch off all slots", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
            
            self.present(alertController, animated: true, completion: nil)
        }
        if (allButtonTouchCheck.count == 10)
        {
            print("segue");
            let amountWon = calculateAmount();
            finalAmount = amountWon;
            allButtonTouchCheck.removeAll();
            arr.removeAll();
            
            //segue to EndViewController
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2))
            {
                self.performSegue(withIdentifier: "endViewForGame3", sender: self);
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let endView: EndViewController = segue.destination as! EndViewController;
        endView.amount = "\(finalAmount)";
    }
    
    func calculateAmount() -> Int
    {
        var amountWon = 0;
        
        for combination in arr
        {
            if (combination.symbol == "3X")
            {
                amountWon += combination.amount * 3;
                combination.label.backgroundColor = UIColor.green;
            }
            if (combination.symbol == "💵")
            {
                amountWon += combination.amount;
                combination.label.backgroundColor = UIColor.green;
            }
        }
        
        return amountWon;
    }
    
}
