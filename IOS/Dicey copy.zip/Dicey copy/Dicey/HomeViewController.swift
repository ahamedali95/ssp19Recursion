//
//  ViewController.swift
//  Dicey
//
//  Created by Ahamed Abbas on 11/14/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    @IBOutlet weak var bestScoreLabel: UILabel!
    @IBOutlet weak var start: UIButton!
    @IBOutlet weak var tableView: UITableView!
    
    var gameName = [String]();
    var winnings = [String]();
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return winnings.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! UITableViewCell;
        cell.textLabel?.text = winnings[indexPath.row];
        return cell;
    }
    
    override func viewDidLoad()
    {
        bestScoreLabel.layer.cornerRadius = 8.0;
        start.layer.cornerRadius = 8.0;
        
        let data = UserDefaults.standard;
        data.set(winnings, forKey: "key");
        //print(data.object(forKey: "key") as Any);
        //print(gameName);
        print("homeView: \(winnings)");
    }

    @IBAction func startGame(_ sender: UIButton)
    {
        self.performSegue(withIdentifier: "testingView", sender: self);
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let testingView: testingViewController = segue.destination as! testingViewController;
        testingView.amount = winnings;
    }

}

