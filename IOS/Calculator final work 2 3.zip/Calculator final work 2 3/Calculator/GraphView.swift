//
//  GraphView.swift
//  Calculator

//

import UIKit

@IBDesignable
class GraphView: UIView {
    
    @IBInspectable
    var scale: CGFloat = 0.50 {
        didSet {
            setNeedsDisplay()
        }
    }
    
    @IBInspectable
    var color: UIColor = UIColor.white {
        didSet {
            setNeedsDisplay()
        }
    }
    @IBInspectable
    var middle: CGPoint = CGPoint()
    {
        didSet {
            setNeedsDisplay()
        }
    }
    
    var GCenter: CGPoint {
        return convert(center, to: superview)
    }
    

    override func draw(_ rect: CGRect) {
        let axes = AxesDrawer(color: color, contentScaleFactor: contentScaleFactor)
        
        axes.drawAxes(in: bounds, origin: GCenter, pointsPerUnit: scale * CGFloat(100))
        
        
        let path = UIBezierPath()
        path.lineWidth = 5.0
        color.set();
        path.stroke();
    }
    
    func zoomIn(recognizer: UIPinchGestureRecognizer) {
     switch recognizer.state {
         case .changed, .ended:
         scale *= recognizer.scale
         recognizer.scale = 1.0
         default:
         break
     }
     }
    
     func Tap(recognizer: UITapGestureRecognizer) {
     switch recognizer.state {
         case .ended:
         middle = recognizer.location(in: self)
         default:
         break
     }
    }
    
    func pan(recognizer: UIPanGestureRecognizer) {
        switch recognizer.state {
        case .changed, .ended:
            let move = recognizer.translation(in: self)
            middle.x += move.x
            middle.y += move.y
            recognizer.setTranslation(CGPoint.zero, in: self)
        default:
            break
        }
    }
}
