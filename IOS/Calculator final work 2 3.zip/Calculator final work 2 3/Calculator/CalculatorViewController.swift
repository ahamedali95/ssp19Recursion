//
//  ViewController.swift
//  Calculator
//
//  Created by student on 9/10/17.
//  Copyright © 2017 Sulaiman Jalloh. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UISplitViewControllerDelegate {
    
    override func awakeFromNib(){
        super.awakeFromNib();
        self.splitViewController?.delegate = self;
    }
    
    func splitViewController(_ splitViewController: UISplitViewController,
                             collapseSecondary secondaryViewController: UIViewController,
                             onto primaryViewController: UIViewController) -> Bool {
        if (primaryViewController.contents == self) {
            if secondaryViewController.contents is GraphViewController {
                return true;
            }
        }
        return false;
    }
    @IBOutlet weak var display: UILabel!
    
    @IBOutlet weak var history: UILabel!
    
    @IBOutlet weak var MemoryDisplay: UILabel!
    
    @IBOutlet weak var tochka: UIButton! {
        didSet {
            tochka.setTitle(decimalSeparator, for: UIControlState())
        }
    }
    
    let decimalSeparator = formatter.decimalSeparator ?? "."
    
    var userInTheMiddleOfTyping = false
    
    @IBAction func touchDigit(_ sender: UIButton) {
        
        let digit = sender.currentTitle!
        if userInTheMiddleOfTyping {
            let textCurrentlyInDisplay = display.text!
            if (digit != decimalSeparator) || !(textCurrentlyInDisplay.contains(decimalSeparator)) {
                display.text = textCurrentlyInDisplay + digit
            }
        } else {
            display.text = digit
            userInTheMiddleOfTyping = true
        }
    }
    
    var firstDisplayValue: Double{
        get{
            return Double(display.text!.replacingOccurrences(of: ",", with: ""))!
        }
    }
    
    var secondDisplayValue: String{
        get{
            return "";
        }
        set{
            display.text = newValue
        }
    }
    
    private var brain = CalculatorBrain ()

    @IBAction func performOPeration(_ sender: UIButton) {
        if userInTheMiddleOfTyping {
            brain.setOperand(firstDisplayValue)
            userInTheMiddleOfTyping = false
        }
        if  let mathematicalSymbol = sender.currentTitle {
            brain.performOperation(mathematicalSymbol)
        }
        displayResult()
    }
    
    private var variables = Dictionary<String,Double>(){
        didSet{
            MemoryDisplay.text = variables.flatMap{$0+":\($1)"}.joined(separator: ", ").beautifyNumbers()
        }
    }
    
    private func displayResult(){
        let evaluatedResult = brain.evaluate(using: variables)
        if let result = evaluatedResult.result{
            //Deciding whether the result is an interger. If it is we want to display it like this: 23,232,221 (no decimal point)
            
            if (result.truncatingRemainder(dividingBy: 1) == 0){
                let stringValue =  String(format: "%.0f", result)
                let doubleValue = Double(stringValue)
                let resultToNSNumber = NSNumber(value: doubleValue!)
                let resultStringValue: String = numberFormatter().string(from: resultToNSNumber)!;
                
                secondDisplayValue = resultStringValue
            }
            //Display only 6 decimal digits
            else{
                let resultToNSNumber = NSNumber(value: result)
                let stringValue = numberFormatter().string(from: resultToNSNumber)
                secondDisplayValue = stringValue!
            }
            if "" != evaluatedResult.description {
                history.text = evaluatedResult.description.beautifyNumbers() + (evaluatedResult.isPending ? "…" : "=")
            }
            else{
                history.text = " "
            }
        }
    }
    
    private func numberFormatter() -> NumberFormatter
    {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 6
        return formatter
    }
    @IBAction func clearAll(_ sender: UIButton) {
        brain = CalculatorBrain()  //new brain
        secondDisplayValue = "0"
        userInTheMiddleOfTyping = false
        history.text = " "
        variables = Dictionary<String,Double>() //clearing the memory value
    }
    
    @IBAction func backspace(_ sender: UIButton) {
        if(userInTheMiddleOfTyping){
            var text = display.text
            let idx = text?.endIndex;
            let last = text?.index(before: idx!);
            text?.remove(at: last!);
            if(text?.isEmpty)!{
                text = "0"
                userInTheMiddleOfTyping = false
            }
            display.text = text
        }
        else{
            brain.undoAction()
            displayResult()
        }
    }
    
    @IBAction func InsertInToMemory(_ sender: UIButton){
        variables["M"] = firstDisplayValue
        userInTheMiddleOfTyping = false;
        displayResult()
    }
    
    
    @IBAction func GetMemoryValue(_ sender: UIButton) {
        brain.setOperand(variable: "M")
        userInTheMiddleOfTyping = false
        displayResult()
    }
    
}

extension String
{
    func beautifyNumbers() -> String{
        return self.replace(pattern: "\\.0+([^0-9]|$)", with: "$1")
    }
    
    func replace(pattern: String, with replacement: String) -> String{
        let regex = try! NSRegularExpression(pattern: pattern, options: .caseInsensitive)
        let range = NSMakeRange(0, self.characters.count)
        return regex.stringByReplacingMatches(in: self, options: [], range: range, withTemplate: replacement)
    }
}
extension UIViewController
{
    var contents: UIViewController{
        if let navigationController = self as? UINavigationController {
            return navigationController.visibleViewController ?? self;
        }
        else {
            return self;
        }
    }
}

let formatter:NumberFormatter = {
    let formatter = NumberFormatter()
    formatter.numberStyle = .decimal
    formatter.maximumFractionDigits = 6
    formatter.notANumberSymbol = "Error"
    formatter.groupingSeparator = " "
    formatter.locale = Locale.current
    return formatter
    
}()
