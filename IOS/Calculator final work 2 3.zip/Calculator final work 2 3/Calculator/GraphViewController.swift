//
//  GraphViewController.swift
//  Copyright © 2017 Hector Gonzi. All rights reserved.
//

import UIKit

class GraphViewController: UIViewController {

    
    
    @IBOutlet var graph: GraphView! {
        didSet {
            graph.addGestureRecognizer(UIPinchGestureRecognizer(target: graph, action: #selector(GraphView.zoomIn(recognizer:))))
            graph.addGestureRecognizer(UIPanGestureRecognizer(target: graph, action: #selector(GraphView.pan(recognizer:))))
            let recognizer = UITapGestureRecognizer(target: graph, action: #selector(GraphView.Tap(recognizer:)))
            recognizer.numberOfTapsRequired = 3
            graph.addGestureRecognizer(recognizer)
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
