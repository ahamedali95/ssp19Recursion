//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

let i = 27

var f: (Double) -> Double
f = sqrt

let x = f(81)
