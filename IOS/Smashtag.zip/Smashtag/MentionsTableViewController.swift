//
//  MentionsTableViewController.swift
//  Smashtag
//
//  Created by Ahamed Abbas on 11/19/17.
//

import UIKit

class MentionsTableViewController: UITableViewController
{
    //Example: mentions = [{title: "Users", data: ["@kunjanimamu", "@donald2517]}, {title: "Hashtags", data: [#taxcuts", "#gop"]}, {title: "URL", data: ["http://wwwe.google.com]}]
    //mentions[0] => title: "Users", data: ["@kunjanimamu", "@donald2517]
    //Example2: mentions1 = [{title: "Users", data: ["@kunjanimamu", "@donald2517"]}]
    //mentions1[indexPath.section].data[indexPath.row] => section is Users and rows are @kunjanimamu, @donald2517
    var mentions = [Mentions]();
    struct Mentions
    {
        var title: String;
        var data: [ItemsNeedForMentions];
        //var tuple: (String, [ItemsNeedForMentions]) { return (title, data) }
    }
    
    enum ItemsNeedForMentions
    {
        case Keyword(String);
        //INSTEAD OF URL, TRY STRING
        case Image(URL);
    }
    
    var tweet: Tweet?
    {
        didSet
        {
            //get user's screen name, not description
            getUserScreenName();
            //difference between screen name and description
            //Example twitter account: Smith @Fridaythe13th
            //THEN tweet.user.description -> @Fridaythe13th AND tweet.user.screenName -> "Smith"
            
            //check whether each mention item is available meaning their count is greater than zero
            //getImageMentionItem();
            getHashtagMentionItem();
            getURLMentionItem();
            getUserTagMentionItem();
            
            //the userTag section must also contain the userTag of the user who made the tweet - EXTRA CREDIT 3
            //addOwnerUserTag();
        }
    }
    
    func getUserScreenName()
    {
        title = tweet?.user.screenName;
    }
    
    func getImageMentionItem()
    {
        //var pictureMentionEle: Mentions? = nil;
        
        //pictureMention is an array in Tweet.swift
        if let pictureMention = tweet?.media
        {
            let pictureCount = pictureMention.count;
            //Enter the if statement only if we have any pictures
            if (pictureCount > 0)
            {
                //retrieve the urls from the framework
                mentions.append(Mentions(title: "Image", data: pictureMention.map{ItemsNeedForMentions.Image($0.url as URL)}));
                //Example of mapping closure:
                //let cast = ["Vivien", "Marlon", "Kim", "Karl"]
                //let lowercaseNames = cast.map { $0.lowercaseString }
                // 'lowercaseNames' == ["vivien", "marlon", "kim", "karl"]
            }
        }
        
    }
    
    func getHashtagMentionItem()
    {
        //var hashtagMentionEle: Mentions? =  nil;
        
        if let hashtagMention = tweet?.hashtags
        {
            let hashtagCount = hashtagMention.count;
            
            if (hashtagCount > 0)
            {
                mentions.append(Mentions(title: "Hashtag", data: hashtagMention.map{ItemsNeedForMentions.Keyword($0.keyword)}));
            }
        }
    }
    
    func getURLMentionItem()
    {
        //var URLMentionEle: Mentions? =  nil;
        
        if let URLMention = tweet?.urls
        {
            let URLCount = URLMention.count;
            
            if (URLCount > 0)
            {
                mentions.append(Mentions(title: "URL", data: URLMention.map{ItemsNeedForMentions.Keyword($0.keyword)}));
            }
        }
    }
    
    func getUserTagMentionItem()
    {
        if let userTagMention = tweet?.userMentions
        {
            var user = [ItemsNeedForMentions.Keyword("@" + tweet!.user.screenName)];
            let userTagMentionCount = userTagMention.count
            
            if (userTagMentionCount > 0)
            {
                //list not only users mentioned in the Tweet, but also the user who posted the Tweet in the first place - EXTRA CREDIT 3
                user += userTagMention.map { ItemsNeedForMentions.Keyword($0.keyword) };
                
                //mentions.append(Mentions(title: "Users", data: userTagMention.map{ItemsNeedForMentions.Keyword($0.keyword)}));
                mentions.append(Mentions(title: "Users", data: user));
            }
        }
    }
    
    
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int
    {
        return mentions.count;
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return mentions[section].data.count;
    }

    //set section header
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        return mentions[section].title;
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        //Example2: mentions1 = [{title: "Users", data: ["@kunjanimamu", "@donald2517"]}]
        //mentions1[indexPath.section].data[indexPath.row] => section is Users and rows are @kunjanimamu, @donald2517
        let mention = mentions[indexPath.section].data[indexPath.row];
        
        switch mention
        {
            case .Image(let url):
                let cell = tableView.dequeueReusableCell(withIdentifier: "Image", for: indexPath) as! MentionsTableViewCell;
                cell.imageURL = url;
                return cell;
        
            //If image, send it to the cell that contains the imageView. Otherwise, put it in the cell that contains the lable.
            case .Keyword(let keyword):
                let cell = tableView.dequeueReusableCell(withIdentifier: "Text", for: indexPath) as UITableViewCell;
                cell.textLabel?.text = keyword;
                return cell;
            
        }
    }
    
    //segue to TweetTableViewController.swift if the user clicks a cell containing a hashtag or userTag, open safari if URL is clicked
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "text"
        {
            let tweetTableViewController = segue.destination as? TweetTableViewController;
            let cell = sender as? UITableViewCell;
            var text = cell?.textLabel?.text;
            
            //if it is an URL, then we do not want to make smashtag search for that URL.
            if (text?.hasPrefix("h"))!
            {
                /*let alertController = UIAlertController(title: "Alert", message:
                    "Cannot search for URL in Smashtag", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))*/
                
                //Open safari with the current text(URL) - EXTRA CREDIT 1
                UIApplication.shared.open(URL(string: text!)!)
            }
            //search for tweets that not only mentions a specific user, but also for tweets which were posted by that user - EXTRA CREDIT 4
            else if (text?.hasPrefix("@"))!
            {
                text = "FROM:\(text!) OR TO:\(text!)";
                tweetTableViewController?.searchText = text;
                tweetTableViewController?.searchTextField.text = text;
            }
            else
            {
                tweetTableViewController?.searchText = text;
                tweetTableViewController?.searchTextField.text = text;
            }
        }
    }
}

 