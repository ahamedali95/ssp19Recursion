//Please note extra credit: 1, 3 & 4
//Swift 3.2
//Application should be on run on Xcode simulator 10.3.1 to get Twitter service.
//Application is universal - tested on iPad Pro (10.5 inch), iPad (5th generation), iPad Air, iPad Air 2, iPhone 5s, iPhone 6, iPhone 6 Plus, iPhone 6s, iPhone 6s Plus, iPhone SE, iPhone 7, iPhone 7 Plus

import UIKit

class TweetTableViewController: UITableViewController,
                                UITextFieldDelegate
{
    //Uses Twitter framework
    private var tweets = [Array<Tweet>]()
    {
        didSet
        {
            print(tweets);
        }
    }
    
    //text to search for tweets - it will shows those tweets
    var searchText: String?
    {
        didSet
        {
            print("SEARCH TEXT: \(searchText!)");
            searchTextField?.text = searchText;
            searchTextField?.resignFirstResponder();
            lastTwitterRequest = nil;                                           //REFRESHING
            tweets.removeAll();                                                 //changing our model
            tableView.reloadData();                                             //tell the tableview about it
                                                                                //fetch some tweets and show the title in the navigation controller
            searchForTweets();
            title = searchText;
        }
    }
    
    //returns a twitter request that matches searchText
    private func twitterRequest() -> Request?
    {
        if let query = searchText, !query.isEmpty                               //if the query not empty, make a reqeuest for the first 100 tweets
        {
            return Request(search: query, count: 100);
        }
        return nil;
    }
    
    private var lastTwitterRequest: Request?;
    
    //calls the twitterRequest function and fetch some tweets based on that function
    private func searchForTweets()
    {
        //fetch the tweets and insert in to our model TWEETS
        //We have memory cycle here because what if the view controller fetch tweets and takes forever. And if the user searches for something else we want our view controller to leave immediately and make a new fetch.
        if let request = lastTwitterRequest?.newer ?? twitterRequest()           //lastTwitterRequest?.newer ?? for REFRESHING
        {
            lastTwitterRequest = request
            request.fetchTweets
                {
                    [weak self] newTweets in                                     //break memory cycle [weak self]
                    DispatchQueue.main.async
                        {
                            if (request == self?.lastTwitterRequest)             //the request that came back is the last we issued then insert the tweets
                            {
                                self?.tweets.insert(newTweets, at: 0);            //changing the model
                                self?.tableView.insertSections([0], with: .fade); //tell the tableView about it, put that in the main queue
                            }
                            self?.refreshControl?.endRefreshing();
                    }
            }
        }
        else
        {
            self.refreshControl?.endRefreshing();
        }
    }
    
    @IBOutlet weak var searchTextField: UITextField!
        {
        didSet
        {
            searchTextField.delegate = self;
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        if (textField == searchTextField)                              //make sure we are operating on the searchtextField because there could be many text fields.
        {
            searchText = searchTextField.text;
        }
        return true;
    }
    
    @IBAction func refreshControl(_ sender: UIRefreshControl)
    {
        searchForTweets();
    }
    override func viewDidLoad()
    {
        super.viewDidLoad();
        tableView.estimatedRowHeight = tableView.rowHeight;
        tableView.rowHeight = UITableViewAutomaticDimension;
        
        searchTextField.layer.cornerRadius = 15.0;
        searchTextField.layer.borderWidth = 2.0;
        searchTextField.layer.borderColor = UIColor.cyan.cgColor;
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int
    {
        return tweets.count;
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return tweets[section].count;
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Tweet", for: indexPath);
        
        //configure the cell
        let tweet = tweets[indexPath.section][indexPath.row];
        /*cell.textLabel?.text = tweet.text; //actual tweet
         cell.detailTextLabel?.text = tweet.user.name; //user who tweeted that tweet*/
        if let tweetCell = cell as? TweetTableViewCell
        {
            tweetCell.tweet = tweet;
        }
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        return "\(tweets.count - section)";
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let mentionsViewController: MentionsTableViewController = segue.destination as! MentionsTableViewController;
        let cell = sender as! UITableViewCell;
        let indexPath = tableView.indexPath(for: cell);
        mentionsViewController.tweet = self.tweets[(indexPath?.section)!][(indexPath?.row)!];
    }
    
    
    @IBAction func prepareForUnwindToRootViewController(Segue: UIStoryboardSegue)
    {
        
    }
}
