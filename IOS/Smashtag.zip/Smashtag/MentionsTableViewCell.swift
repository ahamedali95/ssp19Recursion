//
//  MentionsTableViewCell.swift
//  Smashtag
//
//  Created by Ahamed Abbas on 11/19/17
//

import UIKit

class MentionsTableViewCell: UITableViewCell
{
    @IBOutlet weak var viewForTheImage: UIImageView!
    @IBOutlet weak var activity: UIActivityIndicatorView!
    
    var imageURL: URL?
    {
        didSet
        {
            updateUI();
            print("ARE THERE ANY PICTURES ");
        }
    }
    
    func updateUI()
    {
        //clear any pre-exisiting image
        viewForTheImage.image = nil;
        
        if let url = imageURL
        {
            //start animating until we get the image data
            activity.startAnimating();
            DispatchQueue.global(qos: DispatchQoS.QoSClass.utility).async
            {
                if let imageData = try? Data(contentsOf: url)
                {
                    //UpdateUI in main queue - VERY IMPORTANT!!!
                    DispatchQueue.main.async
                    {
                        self.viewForTheImage?.image = UIImage(data: imageData);
                        self.activity.stopAnimating();
                    }
                }
                else
                {
                    self.viewForTheImage?.image = nil;
                    self.activity.stopAnimating();
                }
            }
        }
    }
}
