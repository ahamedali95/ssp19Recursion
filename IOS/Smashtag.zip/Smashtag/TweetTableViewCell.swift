

import UIKit

class TweetTableViewCell: UITableViewCell
{
    @IBOutlet weak var tweetProfileImageView: UIImageView!
    @IBOutlet weak var tweetCreatedLabel: UILabel!
    @IBOutlet weak var tweetUserLabel: UILabel!
    @IBOutlet weak var tweetTextLabel: UILabel!
    
    //Hex to UIColor conversion: http://uicolor.xyz/
    var hashTagColor: UIColor = UIColor(red:0.00, green:0.63, blue:1.00, alpha:1.0);
    var URLColor: UIColor = UIColor(red:0.70, green:0.26, blue:0.00, alpha:1.0);
    var userTagColor: UIColor = UIColor(red:0.00, green:0.49, blue:0.18, alpha:1.0);
    
    var tweet: Tweet?
    {
        didSet
        {
            updateUI();
        }
    }
    
    private func updateUI()
    {
        resetTweetInfo();
        
        //set the user label
        tweetUserLabel.text = tweet?.user.description;
        
        //format and set the tweet text label in accordance with colors for "mentions"
        formatTweetText(tweet: tweet!);
        
        //set the profile image
        if let profileImageURL = tweet?.user.profileImageURL
        {
            //fix me in homework: it blocks the main thread - dispatch a queue
            //Quality of service(utility) - work doesn’t require an immediate result, such as downloading or importing data.
            DispatchQueue.global(qos: DispatchQoS.QoSClass.utility).async
            {
                if let imageData = try? Data(contentsOf: profileImageURL)
                {
                    //UpdateUI in main queue
                    DispatchQueue.main.async
                    {
                        self.tweetProfileImageView?.image = UIImage(data: imageData);
                    }
                }
                else
                {
                    self.tweetProfileImageView?.image = nil;
                }
            }
        }
        
        //set the tweet's metadata
        if let created = tweet?.created
        {
            let formatter = DateFormatter();
            if (Date().timeIntervalSince(created) > 24*60*60)
            {
                formatter.timeStyle = .short;
            }
            else
            {
                formatter.timeStyle = .short;
            }
            tweetCreatedLabel?.text = formatter.string(from: created);
        }
        else
        {
            tweetCreatedLabel?.text = nil;
        }
    }
    
    func resetTweetInfo()
    {
        tweetProfileImageView.image = nil;
        tweetCreatedLabel.text = nil;
        tweetUserLabel.text = nil;
        tweetTextLabel.text = nil;
    }
    
    func formatTweetText(tweet: Tweet)
    {
        let attributedString = NSMutableAttributedString(string: tweet.text);
        let myAttribute1 = NSForegroundColorAttributeName;
        let myAttribute2 = NSFontAttributeName;
        let myAttribute3 = NSUnderlineStyleAttributeName;
        
        if (tweet.hashtags.isEmpty == false)
        {
            for hashtag in tweet.hashtags
            {
                attributedString.addAttribute(myAttribute1, value: hashTagColor, range: hashtag.nsrange);
                attributedString.addAttribute(myAttribute2, value: UIFont(name: "Baskerville-SemiBoldItalic", size: tweetTextLabel.font.pointSize)!, range: hashtag.nsrange);
            }
        }
        if (tweet.urls.isEmpty == false)
        {
            for link in tweet.urls
            {
                attributedString.addAttribute(myAttribute1, value: URLColor, range: link.nsrange);
            }
        }
        
        if (tweet.userMentions.isEmpty == false)
        {
            for userTag in tweet.userMentions
            {
                attributedString.addAttribute(myAttribute1, value: userTagColor, range: userTag.nsrange);
                attributedString.addAttribute(myAttribute3, value: NSUnderlineStyle.styleSingle.rawValue, range: userTag.nsrange);
            }
        }
        
        tweetTextLabel?.attributedText = attributedString;
    }
}
