//
//  GraphingViewController.swift
//  calculator4
//
//  Created by Ahamed Abbas on 10/31/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import UIKit

class GraphingViewController: UIViewController, GraphingDataSource //Datasource protocol defined in class
{
    private var brain = CalculatorBrain();
    
    @IBOutlet weak var graphingView: GraphingView!
    {
        didSet
        {
            //Pinch to zoom
            let pinchHandler = #selector(GraphingView.changeScale(gesture:));
            let pinchRecognizer = UIPinchGestureRecognizer(target: graphingView, action: pinchHandler);
            graphingView.addGestureRecognizer(pinchRecognizer);
            
            //Pan to move
            let panHandler = #selector(GraphingView.pan(gesture:));
            let panRecognizer = UIPanGestureRecognizer(target: graphingView, action: panHandler);
            graphingView.addGestureRecognizer(panRecognizer);
            
            //Tap to origin
            let tapHandler = #selector(GraphingView.origin(gesture:));
            let tapRecognizer = UITapGestureRecognizer(target: graphingView, action: tapHandler);
            tapRecognizer.numberOfTapsRequired = 2;
            graphingView.addGestureRecognizer(tapRecognizer);
        }
    }
    
    private var operations: Dictionary<String, Double> =
        [
            "π"   : (Double.pi),
            "e"   : (M_E),
        ]
    
    //Conform to protocol
    func calculateYGivenX(x: Double) -> Double
    {
        let result = brain.unaryFunction(value: x)
        print(result);
        return result;
    }
    
    
    

}
