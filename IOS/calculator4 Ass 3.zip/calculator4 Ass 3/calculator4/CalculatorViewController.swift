//
//  ViewController.swift
//  calculator4
//
//  Created by Ahamed Abbas on 9/12/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//


import UIKit

class CalculatorViewController: UIViewController, UISplitViewControllerDelegate
{
    override func awakeFromNib()
    {
        super.awakeFromNib();
        self.splitViewController?.delegate = self;
    }
    
    //Show my master-view on top of the detail view
    func splitViewController(_ splitViewController: UISplitViewController,
                             collapseSecondary secondaryViewController: UIViewController,
                             onto primaryViewController: UIViewController) -> Bool
    {
        if (primaryViewController.contents == self)
        {
            if secondaryViewController.contents is GraphingViewController
            {
                return true;
            }
        }
        return false;
    }
    
    @IBOutlet weak var display: UILabel!
    @IBOutlet weak var descriptionDisplay: UILabel!
    @IBOutlet weak var Mdisplay: UILabel!
    var userInTheMiddleOfTyping: Bool = false;
    
    @IBAction func touchDigit(_ sender: UIButton)
    {
        sender.layer.cornerRadius = 5.0;
        sender.showsTouchWhenHighlighted = true;
        
        let digit = sender.currentTitle!; //computed property
        
        if(userInTheMiddleOfTyping)
        {
            if(digit == ".")
            {
                if (display.text!.range(of: ".") == nil)
                {
                    let textCurrentlyInDisplay = display.text!;
                    display.text = textCurrentlyInDisplay + digit;
                }
            }
            
            else
            {
                let textCurrentlyInDisplay = display.text!;
                display.text = textCurrentlyInDisplay + digit;
            }
        }
            
        else
        {
            display.text = digit;
            userInTheMiddleOfTyping = true;
        }
    }
    
    var displayValue: Double
    {
        get
        {
            return Double(display.text!.replacingOccurrences(of: ",", with: ""))!;
        }
        
    }
    
    var displayValue2: String
    {
        get
        {
            return "";
        }
        
        set
        {
            display.text = newValue;
        }
    }
    
    private var brain: CalculatorBrain = CalculatorBrain();
    
    @IBAction func performOperation(_ sender: UIButton)
    {
        sender.showsTouchWhenHighlighted = true;
        if(userInTheMiddleOfTyping)
        {
            brain.setOperand(displayValue);
            userInTheMiddleOfTyping = false;
        }
        
        if let mathematicalSymbol = sender.currentTitle
        {
            brain.performOperation(mathematicalSymbol);
        }
        
        resultDisplay();
    }
    
    private func resultDisplay()
    {
        let evaluated = brain.evaluate(using: variables);
        
        if let result = evaluated.result
        {
            let formatNumber = NumberFormatter();
            formatNumber.numberStyle = .decimal;
            formatNumber.maximumFractionDigits = 6;
            formatNumber.minimumFractionDigits = 0;
            
            if (result.truncatingRemainder(dividingBy: 1) == 0)     //if the result is an interger, take off the decimal values
            {
                let stringValue =  String(format: "%.0f", result);
                let doubleValue = Double(stringValue);
                let resultToNSNumber = NSNumber(value: doubleValue!);
                let resultStringValue: String = formatNumber.string(from: resultToNSNumber)!;
                
                displayValue2 = resultStringValue;
            }
            else                                                    //if it is a decimal number, display only 6 decimal digits
            {
                let resultToNSNumber = NSNumber(value: result);
                let resultStringValue: String = formatNumber.string(from: resultToNSNumber)!;
                
                displayValue2 = resultStringValue;
            }
        }
        
        if "" != evaluated.description
        {
            descriptionDisplay.text = evaluated.description.beautifyNumbers() + (evaluated.isPending ? "…" : "=");
        }
        else
        {
            descriptionDisplay.text = " ";
        }
    }
    
    private var variables = Dictionary<String,Double>()
    {
        didSet
        {
            Mdisplay.text = variables.flatMap{$0+":\($1)"}.joined(separator: ", ").beautifyNumbers();
        }
    }
    
    @IBAction func memoryInsert(_ sender: UIButton)
    {
        sender.showsTouchWhenHighlighted = true;
        variables["M"] = displayValue;
        userInTheMiddleOfTyping = false;
        resultDisplay();
    }
    
    @IBAction func memoryCall(_ sender: UIButton)
    {
        sender.showsTouchWhenHighlighted = true;
        brain.setOperand(variable: "M");
        userInTheMiddleOfTyping = false;
        resultDisplay();
    }
    
    @IBAction func clearScreen(_ sender: UIButton)
    {
        sender.showsTouchWhenHighlighted = true;
        brain = CalculatorBrain();
        displayValue2 = "0";
        descriptionDisplay.text = " ";
        userInTheMiddleOfTyping = false;
        variables = Dictionary<String,Double>();
    }
    
    @IBAction func undo(_ sender: UIButton)
    {
        sender.showsTouchWhenHighlighted = true;
        if (userInTheMiddleOfTyping)
        {
            var textvalue = display.text;
            let index = textvalue?.endIndex;
            let lastChar = textvalue?.index(before: index!);
            //remove the last number
            textvalue?.remove(at: lastChar!);
            //if it is empty then set the text to be 0
            if (textvalue?.isEmpty)! 
            {
                textvalue = "0";
                userInTheMiddleOfTyping = false;
            }
                display.text = textvalue;
        }
        else
        {
            brain.undo();
            resultDisplay();
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        //Normal iphone view's destination - desginated view controller
        var finalDestination = segue.destination as? UIViewController;
        
        //split view
        if let splitNavigationController = segue.destination as? UINavigationController
        {
            finalDestination = splitNavigationController.visibleViewController;
        }
        
        //going to graphing view controller
        if let gvc = segue.destination as? GraphingViewController
        {
            if let identifier = segue.identifier
            {
                switch identifier
                {
                    case "showGraph":
                        gvc.navigationItem.title = descriptionDisplay.text;
                    default:
                        break;
                }
            }
        }
    }
    
  /*  @IBAction func graph(_ sender: UIButton)
    {
        performSegue(withIdentifier: "graph", sender: self);
    }
   */
}

//if it is ran in iPad, then it is a navigation controller
extension UIViewController
{
    //computer property, no STORAGE IN EXTENSION!
    var contents: UIViewController
    {
        if let navcon = self as? UINavigationController
        {
            return navcon.visibleViewController ?? self;
        }
        else
        {
            return self;
        }
    }
}

extension String
{
    func beautifyNumbers() -> String
    {
        return self.replace(pattern: "\\.0+([^0-9]|$)", with: "$1");
    }
    
    func replace(pattern: String, with replacement: String) -> String
    {
        let regex = try! NSRegularExpression(pattern: pattern, options: .caseInsensitive);
        let range = NSMakeRange(0, self.count);
        return regex.stringByReplacingMatches(in: self, options: [], range: range, withTemplate: replacement);
    }
}

