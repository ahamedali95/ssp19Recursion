//
//  GraphingView.swift
//  calculator4
//
//  Created by Ahamed Abbas on 10/31/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import UIKit

//using data source property to get the plot values
protocol GraphingDataSource: class
{
    func calculateYGivenX(x: Double) -> Double;
}

@IBDesignable
class GraphingView: UIView
{
    weak var dataSource: GraphingDataSource?;
    
    @IBInspectable
    var scale: CGFloat = 0.50 {didSet {setNeedsDisplay()}};
    
    @IBInspectable
    var color: UIColor = UIColor.black {didSet {setNeedsDisplay()}};
    
    @IBInspectable
    var lineWidth: CGFloat = 5.0 {didSet {setNeedsDisplay()}};
    
    @IBInspectable
    var origin: CGPoint = CGPoint() {didSet {setNeedsDisplay()}};
    
    private var centered: Bool = true;
    
    //computed property to place the graph at the center of the screen
    var graphCenter: CGPoint
    {
        return convert(center, from: superview);
    }
    
    override func draw(_ rect: CGRect)
    {
        if (centered == true)
        {
            origin = graphCenter;
            centered = false;
        }
        
        let axes = AxesDrawer(color: color, contentScaleFactor: contentScaleFactor);
        axes.drawAxes(in: bounds, origin: origin, pointsPerUnit: CGFloat(100) * scale);
        
        //HERE WE PLOT X AND Y VALUES!!!!!!!!!!!!!!!
        //{
            
            
        //}
        let path = UIBezierPath();
        path.lineWidth = lineWidth;
        color.set();
        path.stroke();
    }

    //Swift 4 requirement - add @objc attribute before function declaration. Until Swift 4, it was inferred
    @objc func changeScale(gesture: UIPinchGestureRecognizer)
    {
        if (gesture.state == .changed || gesture.state == .ended)
        {
            scale = scale * gesture.scale;
            gesture.scale = 1;
        }
    }
    
    //Swift 4 requirement - add @objc attribute before function declaration. Until Swift 4, it was inferred
    @objc func pan(gesture: UIPanGestureRecognizer)
    {
        if (gesture.state == .changed || gesture.state == .ended)
        {
            let translation = gesture.translation(in: self);
            origin.x = origin.x + translation.x;
            origin.y = origin.y + translation.y;
            gesture.setTranslation(.zero, in: self);
        }
    }
    
    //Swift 4 requirement - add @objc attribute before function declaration. Until Swift 4, it was inferred
    @objc func origin(gesture: UITapGestureRecognizer)
    {
        if (gesture.state == .ended)
        {
            origin = gesture.location(in: self);
        }
    }
}
