//
//  InstructionsViewController.swift
//  Dicey
//
//  Created by Ahamed Abbas on 12/7/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import UIKit

class InstructionsViewController: UIViewController
{
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label3: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad();
        label1.layer.masksToBounds = true;
        label2.layer.masksToBounds = true;
        label3.layer.masksToBounds = true;
        label1.layer.cornerRadius = 5;
        label2.layer.cornerRadius = 5;
        label3.layer.cornerRadius = 5;
    }

}
