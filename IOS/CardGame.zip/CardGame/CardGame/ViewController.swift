

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var card1: UILabel!
    @IBOutlet weak var card2: UILabel!
    @IBOutlet weak var card3: UILabel!
    @IBOutlet weak var card4: UILabel!
    @IBOutlet weak var card5: UILabel!
    
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var betLabel: UITextField!
    @IBOutlet weak var betTextField: UITextField!
    
    var isDealPressed = false
    var betAmount = 0
    var userScore = 0
    var botScore = 0
    
    override func viewDidLoad() {
        amountLabel.text = "100";
        betTextField.delegate = self;
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    @IBAction func deal(_ sender: UIButton) {
        
            isDealPressed = true
            let cardGame = CardGame()
            cardGame.generateCards()
            
            let scoreArr = cardGame.score
            calculateTotalScoreForUser(score: scoreArr);
            
            let cards = cardGame.cards
            let cards1 = cardGame.cards2
        
            let color1 = getColor(suit: cards1[0])
            card1.textColor = color1
            card1.text = cards[0]
        
            let color2 = getColor(suit: cards1[1])
            card2.textColor = color2
            card2.text = cards[1]
        
            let color3 = getColor(suit: cards1[2])
            card3.textColor = color3
            card3.text = cards[2]
        
            let color4 = getColor(suit: cards1[3])
            card4.textColor = color4
            card4.text = cards[3]
        
            let color5 = getColor(suit: cards1[4])
            card5.textColor = color5
            card5.text = cards[4]
        
    }
    
    func getColor(suit: String) -> UIColor
    {
        
        if (suit == "❤️") {
            return UIColor.red
        } else if (suit == "♦️")
        {
            return UIColor.red
        } else {
            return UIColor.black
        }
    }
    
    func calculateTotalScoreForUser(score: [Int]) {
        let startIndex = 0;
        let endIndex = score.count;
        let increment = 1;
        
        let sequence = stride(from: startIndex, to: endIndex, by: increment)
        
        for i in sequence {
            userScore += score[i];
        }
    }

    
    @IBAction func bet(_ sender: UIButton) {
        if (isDealPressed == false) {
            let alertController = UIAlertController(title: "Alert", message:
                "Please make a deal first", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
            self.present(alertController, animated: true, completion: nil)
        } else if (betLabel.text! == "" || betLabel.text! == "0") {
            let alertController = UIAlertController(title: "Alert", message:
                "Please enter a valid bet amount", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
            self.present(alertController, animated: true, completion: nil)
        } else {
            betAmount = Int(betLabel.text!)!
            let cardGame = CardGame()
            cardGame.generateCards()
            let score = cardGame.score
            calculateTotalScoreForBot(score: score)
            
            let cards = cardGame.cards
            let cards1 = cardGame.cards2
            
            let color1 = getColor(suit: cards1[0])
            card1.textColor = color1
            card1.text = cards[0]
            
            let color2 = getColor(suit: cards1[1])
            card2.textColor = color2
            card2.text = cards[1]
            
            let color3 = getColor(suit: cards1[2])
            card3.textColor = color3
            card3.text = cards[2]
            
            let color4 = getColor(suit: cards1[3])
            card4.textColor = color4
            card4.text = cards[3]
            
            let color5 = getColor(suit: cards1[4])
            card5.textColor = color5
            card5.text = cards[4]
            
            isDealPressed = false;
            checkWhoWon();
        }
    }
    
    func calculateTotalScoreForBot(score: [Int]) {
        let startIndex = 0
        let endIndex = score.count
        let increment = 1
        
        let sequence = stride(from: startIndex, to: endIndex, by: increment)
        
        for i in sequence {
            botScore += score[i]
        }
    }
    
    func checkWhoWon() {
        if (userScore * 2 == botScore) {
            let amountWon = betAmount * 2 + Int(amountLabel.text!)!
            amountLabel.text = "\(amountWon)"
        } else if (userScore > botScore) {
            let amountWon = betAmount + Int(amountLabel.text!)!
            amountLabel.text = "\(amountWon)"
        } else if (botScore > userScore) {
            let amountWon = Int(amountLabel.text!)! - betAmount
            amountLabel.text = "\(amountWon)"
        }
    }
    @IBAction func reset(_ sender: UIButton) {
        amountLabel.text = "100"
        isDealPressed = false
        betTextField.text = ""
    }
    
}

