/*You will have a Deck class that represents a full deck of playing cards, 52 cards.
 
 Your Deck class will allow you to draw a card at random from the deck. Once a card has been drawn, it will no longer be part of the deck.*/

import Foundation
class Deck {
    var cards = [String]()
    var score = [Int]()
    
    func generateCards() {
        let cardClass: card = card()
        cardClass.getValue()
        cards.append(cardClass.card)
        score.append(cardClass.score)
        cardClass.getValue()
        cards.append(cardClass.card)
        score.append(cardClass.score)
        cardClass.getValue()
        cards.append(cardClass.card)
        score.append(cardClass.score)
        cardClass.getValue()
        cards.append(cardClass.card)
        score.append(cardClass.score)
        cardClass.getValue()
        cards.append(cardClass.card)
        score.append(cardClass.score)
        
        print(score);
    }
}
