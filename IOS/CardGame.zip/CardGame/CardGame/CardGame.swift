

import Foundation
class CardGame {
    var amount = 100
    var cards = [String]()
    var cards2 = [String]()
    var score = [Int]()
    
    func generateCards() {
        
        let cardClass: card = card()
        cardClass.getValue()
        cards.append(cardClass.card)
        cards2.append(cardClass.card1)
        score.append(cardClass.score)
        
        cardClass.getValue()
        cards.append(cardClass.card)
        cards2.append(cardClass.card1)
        score.append(cardClass.score)
        
        cardClass.getValue()
        cards.append(cardClass.card)
        cards2.append(cardClass.card1)
        score.append(cardClass.score)
        
        cardClass.getValue()
        cards.append(cardClass.card)
        cards2.append(cardClass.card1)
        score.append(cardClass.score)
        
        cardClass.getValue()
        cards.append(cardClass.card)
        cards2.append(cardClass.card1)
        score.append(cardClass.score)
        
        print(score);
    }
}
