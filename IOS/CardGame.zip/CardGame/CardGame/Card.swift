/*You will have a Card class that represents a playing card. Cards have three attributes:
 Value: 2-10, J, Q, K and A
 Suit: ♠, ♥, ♦, and ♣
 Score: This is a computed attribute. A card has a score which is a combination of it's value and suit. For this J, Q, K and A can be considered 11, 12, 13 and 14 respectively. and ♠, ♥, ♦, and ♣ can be 4, 3, 2 and 1 respectively. You need to combine the two to obtain a score. As an example, please note that 10 ♦ should have a higher score than 10 ♣.*/

import Foundation
class card {

    let values = ["2","3","4","5","6","7","8","9","10","J", "Q", "K", "A"];
    let suits = ["♠️","❤️", "♦️", "♣️"];
    var card =  ""
    var score = 0
    var card1 = ""

    func getValue() {
        let num = Int(arc4random()) % values.count
        let value = values[num]
        getSuit(value: value)
    }

    func getSuit(value: String) {
        let num = Int(arc4random()) % suits.count
        let suit = suits[num]
        
        if (value == "J" || value == "Q" || value == "K" || value == "A") {
            let value1 = getScoreForJQKA(value: value)
            getScore(suit: suit, value: value1)
        } else {
            getScore(suit: suit, value: value)
        }
        
        card = "\(value)\(suit)"
        card1 = "\(suit)"
    }

    func getScoreForJQKA(value: String) -> String {
        if (value == "J") {
            return "11"
        } else if (value == "Q") {
            return "12"
        } else if (value == "K") {
            return "13"
        } else {
            return "14"
        }
    }

    func getScore(suit: String, value: String) {
        if (suit == "♠️") {
            score = (4 + Int(value)!)
        } else if (suit == "❤️") {
            score = (3 + Int(value)!)
        } else if (suit == "♦️") {
            score = (2 + Int(value)!)
        } else {
            score = (1 + Int(value)!)
        }
    }
}

