//
//  seguedViewForFirstViewController.swift
//  diceRoll
//
//  Created by Ahamed Abbas on 10/6/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import UIKit

class seguedViewForFirstViewController: UIViewController
{
    @IBOutlet weak var historyLabel: UITextView!
    var receivedString = "";
    override func viewDidLoad()
    {
        super.viewDidLoad();
        historyLabel.text = receivedString;
        self.performSegue(withIdentifier: "unwindToFirstViewController", sender: self)
    }

}
