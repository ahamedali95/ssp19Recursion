//
//  Dice2.swift
//  diceRoll
//
//  Created by Ahamed Abbas on 10/6/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import Foundation

class DiceStateFor4DieGame
{
    func dice1State(value: Int)
    {
        print("2 die game - State of dice 1: " + "\(value)");
    }
    
    func dice2State(value: Int)
    {
        print("2 die game - State of dice 2: " + "\(value)");
    }
    
    func dice3State(value: Int)
    {
        print("2 die game - State of dice 3: " + "\(value)");
    }
    
    func dice4State(value: Int)
    {
        print("2 die game - State of dice 4: " + "\(value)");
    }
}
