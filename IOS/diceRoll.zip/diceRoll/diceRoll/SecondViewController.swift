//
//  SecondViewController.swift
//  diceRoll
//
//  Created by Ahamed Abbas on 10/6/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController
{
    @IBOutlet weak var roll1Label: UILabel!;
    @IBOutlet weak var roll2Label: UILabel!;
    @IBOutlet weak var roll3Label: UILabel!;
    @IBOutlet weak var roll4Label: UILabel!;
    
    let dice: DiceStateFor4DieGame = DiceStateFor4DieGame();
    
    override func viewDidLoad() 
    {
        roll1Label.text = "0";
        roll2Label.text = "0";
        roll3Label.text = "0";
        roll4Label.text = "0";
    }
    
    var allRollingValues = "";
    var score = 0;
    
    @IBAction func roll1(_ sender: UIButton)
    {
        let rollvalue = generateRandomNumber(min: 1, max: 7);
        dice.dice1State(value: rollvalue);
        score += rollvalue;
        let rollStringValue = "\(rollvalue)";
        roll1Label.text = rollStringValue;
        allRollingValues += "{"+rollStringValue+"}" + "\n";
    }
    @IBAction func roll2(_ sender: UIButton)
    {
        let rollvalue = generateRandomNumber(min: 1, max: 7);
        dice.dice2State(value: rollvalue);
        score += rollvalue;
        let rollStringValue = "\(rollvalue)";
        roll2Label.text = rollStringValue;
        allRollingValues += "{"+rollStringValue+"}" + "\n";
    }
    @IBAction func roll3(_ sender: UIButton)
    {
        let rollvalue = generateRandomNumber(min: 1, max: 7);
        dice.dice3State(value: rollvalue);
        score += rollvalue;
        let rollStringValue = "\(rollvalue)";
        roll3Label.text = rollStringValue;
        allRollingValues += "{"+rollStringValue+"}" + "\n";
    }
    
    @IBAction func roll4(_ sender: UIButton)
    {
        let rollvalue = generateRandomNumber(min: 1, max: 7);
        dice.dice4State(value: rollvalue);
        score += rollvalue;
        let rollStringValue = "\(rollvalue)";
        roll4Label.text = rollStringValue;
        allRollingValues += "{"+rollStringValue+"}" + "\n";
    }
    
    @IBAction func rollAll(_ sender: UIButton)
    {
        let rollvalue1 = generateRandomNumber(min: 1, max: 7)
        let rollvalue2 = generateRandomNumber(min: 1, max: 7)
        let rollvalue3 = generateRandomNumber(min: 1, max: 7)
        let rollvalue4 = generateRandomNumber(min: 1, max: 7)
        dice.dice1State(value: rollvalue1);
        dice.dice2State(value: rollvalue2);
        dice.dice3State(value: rollvalue3);
        dice.dice4State(value: rollvalue4);
        score += rollvalue1 + rollvalue2 + rollvalue3 + rollvalue4;
        let rollStringValue = "\(rollvalue1)" + "," + "\(rollvalue2)" + "," + "\(rollvalue3)" + "," + "\(rollvalue4)";
        roll1Label.text = "\(rollvalue1)";
        roll2Label.text = "\(rollvalue2)";
        roll3Label.text = "\(rollvalue3)";
        roll4Label.text = "\(rollvalue4)";
        allRollingValues += "{"+rollStringValue+"}" + "\n";
        
    }
    
    @IBAction func reset(_ sender: UIButton)
    {
        roll1Label.text = "0";
        roll2Label.text = "0";
        roll3Label.text = "0";
        roll4Label.text = "0";
        allRollingValues = "";
        print("TotalScore from 4 die game: " + "\(score)");
        score = 0;
    }
    
    //return an interger between 0 to 7
    func generateRandomNumber(min: Int, max: Int) -> Int
    {
        let randomNum = Int(arc4random_uniform(UInt32(max) - UInt32(min)) + UInt32(min))
        return randomNum
    }
    
    @IBAction func historyView(_ sender: UIButton)
    {
        performSegue(withIdentifier: "history2", sender: self);
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let seguedViewForSecond: seguedViewForSecondViewController = segue.destination as! seguedViewForSecondViewController;
        
        seguedViewForSecond.receivedString = allRollingValues;
    }
    
    @IBAction  func prepareForUnwindTo2(segue: UIStoryboardSegue)
    {
        
    }
    
}

