//
//  Dice.swift
//  diceRoll
//
//  Created by Ahamed Abbas on 10/6/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import Foundation

class DiceStateFor2DieGame
{
    func dice1State(value: Int)
    {
        print("2 die game - State of dice 1: " + "\(value)");
    }
    
    func dice2State(value: Int)
    {
        print("2 die game - State of dice 2: " + "\(value)");
    }
}
