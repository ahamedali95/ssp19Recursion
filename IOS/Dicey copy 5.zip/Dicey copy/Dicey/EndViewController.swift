//
//  EndViewController.swift
//  Dicey
//
//  Created by Ahamed Abbas on 11/23/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import UIKit;
import Social;
import MessageUI;

class EndViewController: UIViewController, MFMailComposeViewControllerDelegate, MFMessageComposeViewControllerDelegate
{
    @IBOutlet weak var amountWonLabel: UILabel!
    var amountArr = [String]();
    var comingFrom = "";
    var amount: String = "";
    
    override func viewDidLoad()
    {
        super.viewDidLoad();
        amountWonLabel.text = "$" + "\(amount)";
        print("endviewcontroller: \(amountArr)");
    }


    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning();
    }
    
    //We want to share the amountWon via Twitter
    @IBAction func shareTwitter(_ sender: UIButton)
    {
        //detect if the ability to share to twitter is AVAILABLE
        if (SLComposeViewController.isAvailable(forServiceType: SLServiceTypeTwitter))
        {
            let twitter: SLComposeViewController = SLComposeViewController(forServiceType: SLServiceTypeTwitter);
            //populate the field
            twitter.setInitialText("My current winnings: \(amountWonLabel.text!) #win #lottery");
            
            //present the view to the user
            self.present(twitter, animated: true, completion: nil);
        }
        //if the ability to share to twitter is UNAVAILABLE
        else
        {
            let alert = UIAlertController(title: "Accounts", message: "Please login to your twitter account within the settings", preferredStyle: UIAlertControllerStyle.alert);
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil));
            self.present(alert, animated: true, completion: nil);
        }
        
    }
    
    //We want to share the amountWon via email
    @IBAction func shareEmail(_ sender: UIButton)
    {
        //check if the ability to send mail is AN option withing the application
        if MFMailComposeViewController.canSendMail()
        {
            let mail: MFMailComposeViewController = MFMailComposeViewController();
            //interact and load it up on the screen
            mail.mailComposeDelegate = self;
            //populate the fields
            mail.setToRecipients(nil);
            mail.setSubject("I bet you cannot beat me");
            mail.setMessageBody("My current winnings: \(amountWonLabel.text!) #win", isHTML: false);
            self.present(mail, animated: true, completion: nil);
        }
        //if the ability to send mail is NOT an option withing the application
        else
        {
            let alert = UIAlertController(title: "Accounts", message: "Please login to your mail account within the settings", preferredStyle: UIAlertControllerStyle.alert);
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil));
            self.present(alert, animated: true, completion: nil);
        }
    }
    
    //dismiss the view
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?)
    {
        self.dismiss(animated: true, completion: nil);
    }
    
    //We want to share the amountWon via SMS
    @IBAction func shareSMS(_ sender: UIButton)
    {
        //check if the ability to send mail is AN option withing the application
        if (MFMessageComposeViewController.canSendText())
        {
            let sms: MFMessageComposeViewController = MFMessageComposeViewController()
            sms.messageComposeDelegate = self;
            //populate the fields
            sms.recipients = nil;
            sms.body = "My current winnings: \(amountWonLabel.text!). Tell me your winnings";
            self.present(sms, animated: true, completion: nil);
        }
        //check if the ability to send mail is NOT option withing the application
        else
        {
            let alert = UIAlertController(title: "Warning", message: "SMS service not enabled", preferredStyle: UIAlertControllerStyle.alert);
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil));
            self.present(alert, animated: true, completion: nil);
        }
    }
    
    //dismiss the view
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult)
    {
        self.dismiss(animated: true, completion: nil);
    }
    
    @IBAction func restartGame(_ sender: UIButton)
    {
        //self.dismiss(animated: false, completion: nil);
        //self.presentingViewController?.dismiss(animated: true, completion: nil);
        self.performSegue(withIdentifier: "homeView", sender: self);
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let homeView: HomeViewController = segue.destination as! HomeViewController;
        homeView.gameName.append(comingFrom);
        homeView.winnings = amountArr;
    }
}
