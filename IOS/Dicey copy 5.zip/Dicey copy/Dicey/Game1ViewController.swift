//
//  DiceViewController.swift
//  Dicey
//
//  Created by Ahamed Abbas on 11/14/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import UIKit

class Game1ViewController: UIViewController
{
    @IBOutlet weak var yourScore1Label: UILabel!
    @IBOutlet weak var yourScore2Label: UILabel!
    @IBOutlet weak var theirScore1Label: UILabel!
    @IBOutlet weak var theirScore2Label: UILabel!
  
    @IBOutlet weak var amount1Label: UILabel!
    @IBOutlet weak var amount2Label: UILabel!
    
    @IBOutlet weak var bestWinningsDisplayLabel: UILabel!
    
    var amount = [String]();
    override func viewDidLoad() {
        print("game1viewcontroller: \(amount)");
    }
    var finalAmount = 0;
    var amount1 = 0;
    var amount2 = 0;
    let amountHolder = [5,10,20,30,40,50,100,200,300,500,150,120,220];
    var allButtonTouchCheck = [String]();
    
    func generateScore() -> Int
    {
        let score = Int(arc4random_uniform(99)) + 1;
        return score;
    }
    
    func generateAmount() -> Int
    {
        let num = Int(arc4random_uniform(UInt32(amountHolder.count - 1)) + 0);
        let amount = amountHolder[num];
        return amount;
    }
    
    @IBAction func yourScore1(_ sender: UIButton)
    {
        allButtonTouchCheck.append("yourScore1");
        let score = generateScore();
        yourScore1Label.text = "\(score)";
        sender.isHidden = true;
    }
    
    @IBAction func theirScore1(_ sender: UIButton)
    {
        allButtonTouchCheck.append("theirScore1");
        let score = generateScore();
        theirScore1Label.text = "\(score)";
        sender.isHidden = true;
    }
    
    @IBAction func yourScore2(_ sender: UIButton)
    {
        allButtonTouchCheck.append("yourScore2");
        let score = generateScore();
        yourScore2Label.text = "\(score)";
        sender.isHidden = true;
    }

    @IBAction func theirScore2(_ sender: UIButton)
    {
        allButtonTouchCheck.append("theirScore2");
        let score = generateScore();
        theirScore2Label.text = "\(score)";
        sender.isHidden = true;
    }
    
    @IBAction func amount1(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount1");
        let amount = generateAmount();
        amount1 = amount;
        amount1Label.text = "$" + "\(amount)" + ".00";
        sender.isHidden = true;
    }
    
    @IBAction func amount2(_ sender: UIButton)
    {
        allButtonTouchCheck.append("amount2");
        let amount = generateAmount();
        amount2 = amount;
        amount2Label.text = "$" + "\(amount)" + ".00";
        sender.isHidden = true;
    }
    
    @IBAction func finish(_ sender: UIButton)
    {
        if (allButtonTouchCheck.count < 6)
        {
            let alertController = UIAlertController(title: "Alert", message:
                "Please scratch off all slots", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
            
            self.present(alertController, animated: true, completion: nil)
        }
        if (allButtonTouchCheck.count == 6)
        {
            let amountWon = calculateAmount();
            finalAmount = amountWon;
            allButtonTouchCheck.removeAll();
            
            //segue to EndViewController
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2))
            {
                self.performSegue(withIdentifier: "endViewForGame1", sender: self)
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let endView: EndViewController = segue.destination as! EndViewController;
        endView.amount = "\(finalAmount)";
        amount.append("\(finalAmount)");
        endView.amountArr = amount;
        endView.comingFrom = "Game1";
    }
    
    func calculateAmount() -> Int
    {
        var totalAmount = 0;
        
        let yourScore1 = Int(yourScore1Label.text!)!;
        let theirScore1 = Int(theirScore1Label.text!)!;
        
        let yourScore2 = Int(yourScore2Label.text!)!;
        let theirScore2 = Int(theirScore2Label.text!)!;
        
        if (yourScore1 > theirScore1)
        {
            totalAmount += amount1;
        }
        
        if (yourScore2 > theirScore2)
        {
            totalAmount += amount2;
        }
        
        return totalAmount;
    }
}
