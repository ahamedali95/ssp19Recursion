//
//  segueViewForFirstViewController.swift
//  slotMachine3
//
//  Created by Ahamed Abbas on 10/7/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import UIKit

class segueViewForFirstViewController: UIViewController
{
    @IBOutlet weak var history: UITextView!;
    
    var receivedString = "";
    override func viewDidLoad()
    {
        super.viewDidLoad()
        history.text = receivedString;
    }
}
