//
//  SlotMachineGame.swift
//  slotMachine3
//
//  Created by Ahamed Abbas on 10/23/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import Foundation
import UIKit

class slotMachineGame
{
    var digits = [UInt32]();
    var colors = [String]();
    var scorePoint = 100;
    var history = "";
    
    func resetGame()
    {
        scorePoint = 100;
    }
    
    func getDigits(D: digit) -> [UInt32]
    {
        D.spinDigit();
        let digits = D.returnValueArray();
        return digits;
    }
    
    func getColors(D: digit) -> [String]
    {
        let colors = D.returnColorArray();
        return colors;
    }
    
    func spinDigits()
    {
        scorePoint = scorePoint - 2;
        let Digit: digit = digit();
        let valueArray = getDigits(D: Digit);
        let colorArray = getColors(D: Digit);
        
        digits = valueArray;
        colors = colorArray;
        
        let randomValue1 = valueArray[0];
        let colorForRandomValue1 = colorArray[0];
        
        let randomValue2 = valueArray[1];
        let colorForRandomValue2 = colorArray[1];
        
        let randomValue3 = valueArray[2];
        let colorForRandomValue3 = colorArray[2];
        
        history += "{" + "\(randomValue1)" + "-" + "\(colorForRandomValue1)" + "," + "\(randomValue2)" + "-" + "\(colorForRandomValue2)" + "," + "\(randomValue3)" + "-" + "\(colorForRandomValue3)" + "}" + "\n";
        
        slotScoring(randomValue1: randomValue1, randomValue2: randomValue2, randomValue3: randomValue3, colorForRandomValue1: colorForRandomValue1, colorForRandomValue2: colorForRandomValue2, colorForRandomValue3: colorForRandomValue3);
    }
    
    func slotScoring(randomValue1: UInt32, randomValue2: UInt32, randomValue3: UInt32, colorForRandomValue1: String, colorForRandomValue2: String, colorForRandomValue3: String)
    {
        //same colors but different digits
        if(((colorForRandomValue1 == colorForRandomValue2) && (colorForRandomValue1 == colorForRandomValue3) && (colorForRandomValue2 == colorForRandomValue3)) && !((randomValue1 == randomValue2) && (randomValue1 == randomValue3) && (randomValue2 == randomValue3)))
        {
            scorePoint = getScore() + 75;
            print("scored extra 75: " + "\(scorePoint)");
        }
        
        //same digits but different color
        if(!((colorForRandomValue1 == colorForRandomValue2) && (colorForRandomValue1 == colorForRandomValue3) && (colorForRandomValue2 == colorForRandomValue3)) && ((randomValue1 == randomValue2) && (randomValue1 == randomValue3) && (randomValue2 == randomValue3)))
        {
            scorePoint = getScore() + 150;
            print("scored extra 150: " + "\(scorePoint)");
        }
        
        //same digits and color
        if(((colorForRandomValue1 == colorForRandomValue2) && (colorForRandomValue1 == colorForRandomValue3) && (colorForRandomValue2 == colorForRandomValue3)) && ((randomValue1 == randomValue2) && (randomValue1 == randomValue3) && (randomValue2 == randomValue3)))
        {
            scorePoint = getScore() + 300;
            print("scored extra 300: " + "\(scorePoint)");
        }
    }
    
    func getScore() -> Int
    {
        return scorePoint;
    }
    
    func getHistory() -> String
    {
        return history;
    }
    
    func setHistory(s: String)
    {
        history = s;
    }
    
    func returnDigits() -> [UInt32]
    {
        return digits;
    }
    
    func returnColors() -> [String]
    {
        return colors;
    }
}
