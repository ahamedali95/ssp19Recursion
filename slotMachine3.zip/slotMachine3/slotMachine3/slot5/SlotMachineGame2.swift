//
//  SlotMachineGame.swift
//  slotMachine3
//
//  Created by Ahamed Abbas on 10/23/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import Foundation
import UIKit

class slotMachineGame2
{
    var digits = [UInt32]();
    var colors = [String]();
    var scorePoint = 100;
    var history = "";
    
    func resetGame()
    {
        scorePoint = 100;
    }
    
    func getDigits(D: digit2) -> [UInt32]
    {
        D.spinDigit();
        let digits = D.returnValueArray();
        return digits;
    }
    
    func getColors(D: digit2) -> [String]
    {
        let colors = D.returnColorArray();
        return colors;
    }
    
    func spinDigits()
    {
        scorePoint = scorePoint - 2;
        let Digit: digit2 = digit2();
        let valueArray = getDigits(D: Digit);
        let colorArray = getColors(D: Digit);
        
        digits = valueArray;
        colors = colorArray;
        
        let randomValue1 = valueArray[0];
        let colorForRandomValue1 = colorArray[0];
        
        let randomValue2 = valueArray[1];
        let colorForRandomValue2 = colorArray[1];
        
        let randomValue3 = valueArray[2];
        let colorForRandomValue3 = colorArray[2];
        
        let randomValue4 = valueArray[3];
        let colorForRandomValue4 = colorArray[3];
        
        let randomValue5 = valueArray[4];
        let colorForRandomValue5 = colorArray[4];
        
        history += "{" + "\(randomValue1)" + "-" + "\(colorForRandomValue1)" + "," + "\(randomValue2)" + "-" + "\(colorForRandomValue2)" + "," + "\(randomValue3)" + "-" + "\(colorForRandomValue3)" + "-" + "\(randomValue4)" + "-" + "\(colorForRandomValue4)" + "," + "\(randomValue5)" + "-" + "\(colorForRandomValue5)" + "}" + "\n";
        
        slotScoring(randomValue1: randomValue1, randomValue2: randomValue2, randomValue3: randomValue3, randomValue4: randomValue4, randomValue5: randomValue5, colorForRandomValue1: colorForRandomValue1, colorForRandomValue2: colorForRandomValue2, colorForRandomValue3: colorForRandomValue3, colorForRandomValue4: colorForRandomValue4, colorForRandomValue5: colorForRandomValue5);
        }
    
    func slotScoring(randomValue1: UInt32, randomValue2: UInt32, randomValue3: UInt32, randomValue4: UInt32, randomValue5: UInt32, colorForRandomValue1: String, colorForRandomValue2: String, colorForRandomValue3: String, colorForRandomValue4: String, colorForRandomValue5: String)
    {
        //same color but different digits
        if(((colorForRandomValue1 == colorForRandomValue2) && (colorForRandomValue1 == colorForRandomValue3) && (colorForRandomValue1 == colorForRandomValue4) && (colorForRandomValue1 == colorForRandomValue5) && (colorForRandomValue2 == colorForRandomValue3) && (colorForRandomValue2 == colorForRandomValue4) && (colorForRandomValue2 == colorForRandomValue5) && (colorForRandomValue3 == colorForRandomValue4) && (colorForRandomValue3 == colorForRandomValue5) && (colorForRandomValue4 == colorForRandomValue5)) && !((randomValue1 == randomValue2) && (randomValue1 == randomValue3) && (randomValue1 == randomValue4) && (randomValue1 == randomValue5) && (randomValue2 == randomValue3) && (randomValue2 == randomValue4) && (randomValue2 == randomValue5) && (randomValue3 == randomValue4) && (randomValue3 == randomValue5) && (randomValue4 == randomValue5)))
        {
            scorePoint = getScore() + 125;
            print("scored extra 125: " + "\(scorePoint)");
        }
        
        //same digits but different color
        if(!((colorForRandomValue1 == colorForRandomValue2) && (colorForRandomValue1 == colorForRandomValue3) && (colorForRandomValue1 == colorForRandomValue4) && (colorForRandomValue1 == colorForRandomValue5) && (colorForRandomValue2 == colorForRandomValue3) && (colorForRandomValue2 == colorForRandomValue4) && (colorForRandomValue2 == colorForRandomValue5) && (colorForRandomValue3 == colorForRandomValue4) && (colorForRandomValue3 == colorForRandomValue5) && (colorForRandomValue4 == colorForRandomValue5)) && ((randomValue1 == randomValue2) && (randomValue1 == randomValue3) && (randomValue1 == randomValue4) && (randomValue1 == randomValue5) && (randomValue2 == randomValue3) && (randomValue2 == randomValue4) && (randomValue2 == randomValue5) && (randomValue3 == randomValue4) && (randomValue3 == randomValue5) && (randomValue4 == randomValue5)))
        {
            scorePoint = getScore() + 250;
            print("scored extra 250: " + "\(scorePoint)");
        }
        
        //same digits and color
        if(((colorForRandomValue1 == colorForRandomValue2) && (colorForRandomValue1 == colorForRandomValue3) && (colorForRandomValue1 == colorForRandomValue4) && (colorForRandomValue1 == colorForRandomValue5) && (colorForRandomValue2 == colorForRandomValue3) && (colorForRandomValue2 == colorForRandomValue4) && (colorForRandomValue2 == colorForRandomValue5) && (colorForRandomValue3 == colorForRandomValue4) && (colorForRandomValue3 == colorForRandomValue5) && (colorForRandomValue4 == colorForRandomValue5)) && ((randomValue1 == randomValue2) && (randomValue1 == randomValue3) && (randomValue1 == randomValue4) && (randomValue1 == randomValue5) && (randomValue2 == randomValue3) && (randomValue2 == randomValue4) && (randomValue2 == randomValue5) && (randomValue3 == randomValue4) && (randomValue3 == randomValue5) && (randomValue4 == randomValue5)))
        {
            scorePoint = getScore() + 500;
            print("scored extra 500: " + "\(scorePoint)");
        }
        
    }
    
    func getScore() -> Int
    {
        return scorePoint;
    }
    
    func getHistory() -> String
    {
        return history;
    }
    
    func setHistory(s: String)
    {
        history = s;
    }
    
    func returnDigits() -> [UInt32]
    {
        return digits;
    }
    
    func returnColors() -> [String]
    {
        return colors;
    }
    
}
