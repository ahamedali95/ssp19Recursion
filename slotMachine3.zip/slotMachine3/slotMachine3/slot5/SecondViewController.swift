//
//  SecondViewController.swift
//  slotMachine3
//
//  Created by Ahamed Abbas on 10/7/17.
//  Copyright © 2017 Ahamed Abbas. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController
{
    @IBOutlet weak var slot1Label: UILabel!;
    @IBOutlet weak var slot2Label: UILabel!;
    @IBOutlet weak var slot3Label: UILabel!;
    @IBOutlet weak var slot4Label: UILabel!;
    @IBOutlet weak var slot5Label: UILabel!;
    @IBOutlet weak var scoreLabel: UILabel!;
    
    let slotMachine: slotMachineGame2 = slotMachineGame2();
    
    override func viewDidLoad()
    {
        scoreLabel.text = "\(slotMachine.getScore())";
    }
    
    @IBAction func spin(_ sender: UIButton)
    {
        sender.showsTouchWhenHighlighted = true;
        if(slotMachine.getScore() >= 2)
        {
            slotMachine.spinDigits();
            let score = slotMachine.getScore();
            print("5 slot - current score: " + "\(score)");
            scoreLabel.text = "\(score)";
            
            var valueArray = slotMachine.returnDigits();
            var colorArray = slotMachine.returnColors();
            
            let randomValue1 = valueArray[0];
            let colorForRandomValue1 = colorArray[0];
            slot1Label.textColor = getColor(color: colorForRandomValue1)
            slot1Label.text = "\(randomValue1)";
            
            let randomValue2 = valueArray[1];
            let colorForRandomValue2 = colorArray[1];
            slot2Label.textColor = getColor(color: colorForRandomValue2)
            slot2Label.text = "\(randomValue2)";
            
            let randomValue3 = valueArray[2];
            let colorForRandomValue3 = colorArray[2];
            slot3Label.textColor = getColor(color: colorForRandomValue3)
            slot3Label.text = "\(randomValue3)";
            
            let randomValue4 = valueArray[3];
            let colorForRandomValue4 = colorArray[3];
            slot4Label.textColor = getColor(color: colorForRandomValue4);
            slot4Label.text = "\(randomValue4)";
            
            let randomValue5 = valueArray[4];
            let colorForRandomValue5 = colorArray[4];
            slot5Label.textColor = getColor(color: colorForRandomValue5)
            slot5Label.text = "\(randomValue5)";
        }
    }
    
    func getColor(color: String) -> UIColor
    {
        if(color == "purple")
        {
            return UIColor.purple
        }
        else if(color == "green")
        {
            return UIColor.green;
        }
        else if(color == "red")
        {
            return UIColor.red;
        }
        else if(color == "blue")
        {
            return UIColor.blue;
        }
        else
        {
            return UIColor.yellow;
        }
    }
    
    @IBAction func resetGame(_ sender: UIButton)
    {
        sender.showsTouchWhenHighlighted = true;
        slot1Label.text = "";
        slot2Label.text = "";
        slot3Label.text = "";
        slot4Label.text = "";
        slot5Label.text = "";
        
        slotMachine.resetGame();
        scoreLabel.text = "\(slotMachine.getScore())";
        slotMachine.setHistory(s: "");
    }
    
    
    @IBAction func historyView(_ sender: UIButton)
    {
        sender.showsTouchWhenHighlighted = true;
        performSegue(withIdentifier: "historyForSecondViewController", sender: self);
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let seguedViewForSecond: segueViewForSecondViewController = segue.destination as! segueViewForSecondViewController;
        
        seguedViewForSecond.receivedString = slotMachine.getHistory();
    }
    
    @IBAction func prepareForUnwindTo2(Segue: UIStoryboardSegue)
    {
        
    }
}

