import Foundation
import UIKit

class digit2
{
    let colors = ["blue", "purple", "red", "green"];
    var valueArray = [UInt32]();
    var colorArray = [String]();
    
    func spinDigit()
    {
        let randomValue1 = pickDigit();
        valueArray.append(randomValue1);
        let color1 = pickColor();
        colorArray.append(color1);
        
        let randomValue2 = pickDigit();
        valueArray.append(randomValue2);
        let color2 = pickColor();
        colorArray.append(color2);
        
        let randomValue3 = pickDigit();
        valueArray.append(randomValue3);
        let color3 = pickColor();
        colorArray.append(color3);
        
        let randomValue4 = pickDigit();
        valueArray.append(randomValue4);
        let color4 = pickColor();
        colorArray.append(color4);
        
        let randomValue5 = pickDigit();
        valueArray.append(randomValue5);
        let color5 = pickColor();
        colorArray.append(color5);
    }
    
    func pickDigit() -> UInt32
    {
        let randNum = UInt32(arc4random()) % 10;
        return randNum;
    }
    
    func pickColor() -> String
    {
        let randomValue = Int(arc4random()) % 4;
        let generatedColor = colors[randomValue];
        return generatedColor;
    }
    
    func getDigit(num: Int) -> Int
    {
        return num;
    }
    
    func getColor(color: String) -> String
    {
        return color;
    }
    
    func returnValueArray() -> [UInt32]
    {
        return valueArray;
    }
    
    func returnColorArray() -> [String]
    {
        return colorArray;
    }
}
